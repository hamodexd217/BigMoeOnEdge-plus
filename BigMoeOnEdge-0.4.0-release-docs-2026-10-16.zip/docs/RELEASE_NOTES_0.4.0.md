# BigMoeOnEdge+ v0.4.0 — Release Notes

**Release date:** 2026-10-16

**Version name:** `0.4.0`

**Source version code:** `4`

**Application ID:** `com.bigmoe.onedge`

> **Build/QA status:** these notes document changes present in the source tree. Before publishing the binary, build the APK with the required Android SDK/NDK, run unit tests, install it on a real device, and complete the checklist below. The current packaging environment could not download Gradle 8.9, so it has not produced a verified APK.

## Highlights

v0.4.0 focuses on more convenient GGUF loading, a more polished portrait-first chat experience, premium-inspired themes, optional image search, less noisy settings, and improved streaming UI work. It also consolidates the model-management, MTP, tool, multimodal, workspace and API work carried in the current source bundle.

## 1. Chat UI and navigation

- Increased the left inset of the chat-history pane so the **CHATS** heading is no longer pressed against the screen edge.
- Replaced the portrait chat's top-left back action with a hamburger menu that opens the chat-history drawer.
- Kept the persistent history panel on wide screens; the modal drawer is intended for narrow/portrait layouts.
- Assistant response bubbles now use the available width of the conversation pane; user bubbles remain compact and right-aligned.
- Restyled ordered-list numbers and bullet markers to follow the selected theme.
- Rendered Markdown pipe tables as styled table cells with horizontal scrolling when the table is wider than the screen.

## 2. Premium-inspired palettes

The featured picker is trimmed to twelve presets:

1. Paper
2. Sand
3. Sage
4. Catppuccin Latte
5. Pearl
6. Ocean
7. ChatGPT Dark
8. Claude Warm
9. Gemini Night
10. Midnight
11. AMOLED Black
12. Coffee

The palette catalogue still contains the older presets so saved palette IDs are not invalidated by this picker change. Custom palettes remain supported, including the nine-colour editor. The system-dark fallback uses ChatGPT Dark. The palette check in this source pass evaluated background-mode and contrast thresholds; appearance must still be checked on real devices and display settings.

## 3. Model addition and GGUF handling

- **Add GGUF from storage (no copy)** is the primary Models action. It uses the Android document picker and registers the real path where supported instead of duplicating multi-gigabyte model files.
- The app can route users to Android's **Allow access to manage all files** settings page when Android 11+ blocks access to the selected shared-storage path; it retries registration after returning.
- **Import GGUF file(s) (copy)** remains available for virtual/cloud providers and other sources that do not expose a real filesystem path, and for users who prefer an app-private copy.
- The advanced manual absolute-path form remains available. It has clearer validation for relative paths, missing files, directories and unreadable paths.
- Copy-import can select a complete split GGUF shard set at once, validates numbering/metadata and represents the shards as one model. Rename/delete operations apply to the full imported set.
- Project documentation now explains the difference between no-copy registration and copy import.

**Storage caveats:** the no-copy flow does not make every Android `content://` provider compatible with the native loader. Shared/emulated storage may use buffered I/O and can be slower than app-private storage. No-copy saves duplicate disk space but does not promise faster generation. `MANAGE_EXTERNAL_STORAGE` is a restricted permission and may affect eligibility for Google Play distribution; check the current policy before publishing there.

## 4. MTP sidecars and speculative decoding

- Added an optional separate MTP draft GGUF sidecar list/picker and attach/detach flow per target model.
- The separate draft path and target model path stay distinct; sidecars are loaded only when MTP and the separate-sidecar toggle are selected.
- Split target GGUF imports require a complete numbered set; later shards do not appear as standalone target models.
- Removed the previous rejection that prevented selecting a separate MTP sidecar together with Expert Streaming for the main target model.
- The main MoE target keeps its Expert Streaming path while the separate sidecar is mapped independently. Updated the Settings copy to explain the memory trade-off and fallback behavior.

**Important boundary:** separate sidecars are currently supported only for `general.architecture=qwen4exp`. Sidecar tensors themselves use ordinary mmap and are not served by an independent expert-stream source; do not claim that the sidecar's own experts are streamed. If loading the sidecar fails or it is incompatible, the application can fall back to ordinary target-model generation with speculation disabled and a visible warning. MTP conversion commands in the docs are examples and have not been validated against a real checkpoint in this environment. Throughput/acceptance/RAM need device testing.

## 5. Image search and web tools

- Added the optional `image_search` tool backed by Wikimedia Commons.
- Image results appear in a two-column thumbnail-card grid and include a source-page URL plus available creator/licence metadata.
- Source and thumbnail hosts are validated, thumbnail loading/caching happens away from the UI thread, and result payload size is bounded.
- Image Search shares the chat globe/Web Search toggle. Network tools remain off by default and are not activated merely by installing this version.
- Existing web search provider order remains Brave (when configured), SearXNG (when configured), DuckDuckGo HTML, then Wikipedia fallback. A network connection is required for web/image searching.

## 6. Markdown, code and artifacts

- Improved assistant-message rendering for headings, inline markup, numbered/nested lists, bullets and table grids.
- Code fences are parsed consistently for rendering and artifact detection. Code blocks support copy-code-only and, for larger snippets, opening as artifacts.
- Markdown, HTML, SVG and Mermaid artifact previews remain available under their respective sandbox rules. Other language artifacts are syntax-highlighted and copyable; the app does not contain an interpreter for arbitrary languages.
- Best-effort math conversion makes common LaTeX expressions more readable with Unicode symbols. It is not a full TeX layout engine, and wide equations/tables may require horizontal scrolling.
- JavaScript artifacts execute only when the Run button is pressed, in an offline sandboxed WebView with no file/network access and a time limit.

## 7. Fresh-install defaults and settings layout

For users who have not saved a preference, the defaults are:

- System prompt: empty.
- Files, Code and Utilities tools: off.
- Web Search (and therefore Image Search): off.
- Thinking: off.
- Guess-ahead/speculative decoding: off.
- Generated token limit: unlimited by a separate output cap, ending at available context/other stop conditions.
- Auto-load last model: off.
- Local API server: off.
- Optional NPU prefill: off.

Settings sections have been reorganized and the performance/engine controls are grouped under a collapsible section. No settings section or toggle was removed as part of this layout change. Existing persisted preferences are preserved rather than reset by an app update.

“Unlimited” refers only to the output-token cap. It does not remove the model's context limit, memory limits, time constraints or stop conditions.

## 8. UI/performance work

- Coalesced bursts of streamed text/reasoning/progress into StateFlow snapshots at roughly 30 Hz and flushes pending text at event boundaries/finalization.
- Bounded chat auto-scroll work to roughly 30 passes per second while observing the latest streaming state.
- Retained optimized native Release compilation for the engine, even for the debug APK variant.

These changes target avoidable UI/recomposition work. They do not guarantee a specific tokens/second gain and do not replace benchmarking on the target phone/model.

## 9. Existing capabilities included in this source bundle

The following functionality remains part of the v0.4.0 source and is documented here so the release description is complete:

- Persistent multi-chat history backed by Room, per-chat draft/attachment state, message copy/edit, stop generation and engine telemetry.
- Expert-streamed MoE inference and configurable context, sampling, cache, dense weights, I/O/compute threads, prefetch, routing and speculation settings.
- Files/workspace tools with read/write/search/create/edit/rename/delete/folder/project/ZIP operations and approval for destructive changes.
- Code tools for code search/analysis and `run_javascript`; offline utility tools for time/date, calculator, unit conversion, random values and device information.
- Text/code attachments (up to 256 MB; files over 8 MB warn), bounded archive/document text extraction (1 MB per archive entry, 24 MB total, 5,000 entries), image/video attachment flow and `mmproj`-gated vision path. Unsafe archive paths are skipped. Gallery-selected media is copied into app-private storage during preparation. Attachment preparation now aborts generation on read/decode failure rather than silently continuing with missing context.
- Workspace artifacts and viewers for Markdown/HTML/SVG/Mermaid, with syntax-highlighted code artifacts.
- Optional local OpenAI Chat Completions-compatible and Anthropic Messages-compatible HTTP endpoints; the server is off by default, uses API-key auth by default and binds to loopback unless explicitly configured otherwise.
- Optional, separate Qualcomm Hexagon/NPU build path. The normal APK is CPU-only and does not falsely advertise NPU support when the native library lacks it.
- Engine integration fixes for saved-history replay, KV-prefix management/rollback, unlimited generation within the context, context/token telemetry, speculative-tail handling and the multimodal `mmproj` path. The latest-non-empty CSV sharing path skips empty session files.

## 10. Known limitations

- Tool calling is prompt-based rather than grammar-constrained; weaker models may fail to produce valid tool-call syntax.
- Separate MTP sidecars are limited to `qwen4exp`; the sidecar uses mmap and can increase memory pressure.
- Shared-storage model reads can be slower than app-private storage; provider and permission behavior differs by Android version/device.
- Image/video inference and `mmproj` behavior require testing with the exact model/projector/device combination. Video uses sampled frames and may put pressure on RAM/context.
- The local API stateless path does not perform vision inference on image request payloads; it uses a text placeholder. Some client fields are ignored and reported in `X-BigMoe-Ignored`.
- Mermaid preview may fetch its renderer from jsDelivr; ordinary artifact content uses restrictive network/file sandboxing.
- No voice input is included. Math is best-effort conversion, not full LaTeX typesetting.
- The Android Gradle unit/instrumentation suite and final APK have not been built/verified in this environment due the unavailable Gradle download and Android SDK/NDK setup.

## 11. Pre-publish checklist

- [ ] Confirm `versionName = "0.4.0"` and set `versionCode` above the highest version code already distributed.
- [ ] Run `./gradlew clean assembleRelease --no-daemon` with JDK 17, SDK 35, NDK `27.0.12077973` and CMake `3.22.1` (or use the project's CI build workflow).
- [ ] Run `./gradlew testDebugUnitTest --no-daemon` and review every failure.
- [ ] Run instrumentation tests on an emulator/device where available.
- [ ] Install the APK on the target phone and verify portrait hamburger/history navigation, assistant full-width layout, user bubble alignment and keyboard/composer placement.
- [ ] Try every featured light/dark theme, switching themes during a conversation and after restart; confirm an existing legacy theme can still be changed.
- [ ] On a fresh data install, verify blank system prompt, tools/web/thinking/speculation off, unlimited output cap and API server off. Separately confirm updating an existing install preserves saved preferences.
- [ ] Test no-copy selection from shared Internal storage on Android 10 and Android 11+; test canceling/denying all-files access and verify copy import remains usable.
- [ ] Test that cloud/virtual `content://` providers fall back gracefully to copy import.
- [ ] Test a single GGUF, a valid complete split-GGUF set and an invalid/incomplete shard set.
- [ ] Test an actual compatible `qwen4exp` target plus matching MTP sidecar with Expert Streaming, then measure speed/acceptance/RAM with and without MTP.
- [ ] Test Web Search OFF/ON, search provider failure, image search result links/thumbnails/attribution and no external search when the globe is off.
- [ ] Test vision with a matching model+`mmproj`, a second image turn, a short video at several sampled-frame counts, memory/context use, and speculation interactions.
- [ ] Test file/code/utility tools, destructive-operation approval, workspace confinement, archive limits and JavaScript sandbox boundaries.
- [ ] Test local API server disabled by default, loopback binding, authentication, streaming, queue/preemption and documented unsupported image input.
- [ ] Test optional NPU only with an APK built with the required DSP/native payload on supported hardware.
- [ ] Review `MANAGE_EXTERNAL_STORAGE` eligibility for the intended distribution channel and all vendored dependency licences/notices.
- [ ] Attach the APK, publish the user-facing notes above, and label the release verified only after the checks actually pass.
