# Context figure and KV reuse (bug report: "0 / 64,000 ctx" after a 1-token reply)

## What was wrong
The chat footer's "N / n_ctx" comes from `RunSummary::n_past` -> JNI `nPast` -> `AgentController` -> `GenerationManager` -> the message row.
The engine computed `n_past` as `im.kv_tokens.size()` **after** the end-of-turn trim of the speculative (MTP / n-gram) group.

That trim removes KV positions beyond what was shown to the user. It matters when a draft token that was an end-of-generation
token (EOG) got accepted: it is decoded into the KV but never emitted. For attention-only models `llama_memory_seq_rm` removes it and
all is well. A **recurrent / hybrid** memory (Qwen3.5 is one) only moves its state forward, so `seq_rm` of a tail position returns
`false`. The old code answered a failed trim by `clear_memory()` + `kv_tokens.clear()`, so the summary then read
`kv_tokens.size() == 0` (footer "0 / 64,000") and the next turn had to prefill everything again.

Reported turn 3: 77-token prompt, reply "no" (1 token), `mtp_drafted=2 mtp_accepted=1 mtp_decodes=1`: the draft after "no" was the EOG token,
it was accepted, the trim failed, the KV was wiped, `n_past` read 0. Turns 1 and 2 ended on an EOG that was *sampled*, not drafted: it is
never decoded, nothing to trim, so they were fine. This is read from the code; it was not reproduced on a device.

## Fix (`patches/0005-ctx-used-and-speculative-tail.patch`, `core/src/engine/session.cpp`)
1. `n_ctx_used = prompt tokens + generated tokens` is computed from counters **before** any trim, and `n_past` is set from it. For every
   turn whose KV survived it is the same number as before (so turns 1 and 2 still show 22 and 62).
2. The unemitted tail of the last group is remembered (`group_surplus`). If the trim fails on a non-cancelled chat turn the tail is **kept and
   appended to `kv_tokens`** (it is real, decoded context) instead of wiping the KV. `kv_tokens` still describes the KV exactly.
   Cancelled turns, one-shot runs and image turns keep the old clear-everything behaviour.
3. Kotlin: `AgentController` no longer lets a 0 overwrite a known context figure.

## New metrics (also on the `# summary` CSV line)
| key | meaning |
|---|---|
| `n_ctx_used` | prompt + generated tokens of the turn (same as `n_past`) |
| `n_prompt_total` | tokens in the rendered prompt |
| `n_reused` | leading tokens served from the KV |
| `n_prefill_eval` | tokens actually evaluated by prefill this turn (= `n_prompt_total - n_reused`; the old `n_prompt` already meant this) |
| `kv_reuse` | 0 nothing to reuse, 1 whole cache was a prefix, 2 diverged and the tail was dropped, 3 diverged **and the memory refused to drop it: full re-prefill** |

## Is the KV prefix reused between turns?
In the code: yes, when it can be. The reported `n_prompt` (13, 35, 77) is the number of tokens prefill evaluated, so it growing with the
conversation means `n_reused` was 0: each turn re-prefilled everything. Two things can cause that here, and `kv_reuse` now tells them apart:
* the wiped KV described above (fixed for the accepted-EOG case), and
* **history re-rendering diverges from what was generated**: Qwen-style templates drop the `<think>` block of earlier assistant turns, so
  the new prompt differs from the cached one right after `assistant\n`. On attention models the common prefix (system + first user turn) is
  kept; on a hybrid/recurrent memory a partial removal is refused, so the engine prefills everything (`kv_reuse = 3`). That is a limit of
  the memory type, not a bug; avoiding it would need recurrent-state checkpoints (as llama-server's `--ctx-checkpoints`), which this change does not add.
The "fixed ~3 s" in prefill time is not explained by this change; it was not investigated.

## What was and was not checked
`g++ -fsyntax-only` (session.cpp, with and without mtmd; csv_metrics_sink.cpp) and `-Wall -Wextra`: clean. `git apply` of 0004 then 0005 onto the pristine tree
reproduces the working tree. **Not run**: no model here, so the failing turn was not reproduced and the fix not executed.
