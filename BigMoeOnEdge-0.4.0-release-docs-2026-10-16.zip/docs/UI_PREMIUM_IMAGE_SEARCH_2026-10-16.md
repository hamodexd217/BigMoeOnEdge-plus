# Premium chat / image search pass — 2026-10-16

## Changes
- Increased the horizontal inset of the history panel, so the `CHATS` heading has breathing room in compact split-pane layouts.
- Assistant bubbles now use the full width of the available conversation pane; user messages remain compact and right-aligned.
- Markdown ordered lists use theme-aware number badges and bullets use clear markers. Pipe tables render as a styled cell grid with horizontal scrolling for wider tables.
- The compact featured palette group remains at 12 presets. It now includes Paper/Sand/Sage/Pearl/Ocean alongside ChatGPT Dark, Claude Warm, Gemini Night, Midnight, AMOLED and Coffee. Legacy palette IDs stay registered; the system-dark fallback is now ChatGPT Dark.
- Added an optional `image_search` tool based on the Wikimedia Commons API. It returns source-page links and available creator/license metadata, renders thumbnails as a two-column card grid, validates source/thumbnail hosts, and loads/caches thumbnails off the UI thread. The result payload is size-bounded to preserve valid structured output.
- Image search shares the existing globe/Web Search opt-in; Web Search remains off by default, so no network tool was enabled by this patch.
- Added unit coverage for the image-search API payload and adjusted the tool-enabled regression test. Updated UI labels/docs to explain that the globe includes image search.

## Compatibility / preserved behavior
- Existing featured picker stays at 12 items; old palette presets remain in the complete palette registry so existing saved theme IDs still resolve.
- No settings sections or toggles were removed.
- Previously added defaults are preserved: blank system prompt, no tools enabled by default, and unlimited-by-context generation (`maxTokens <= 0`).
- Earlier no-copy GGUF model selection remains in the project inherited from the preceding patch.

## Validation
- Palette definitions were checked with a local contrast/luminance script: all 36 presets pass the existing background-mode and contrast thresholds, and the featured list remains 12 items.
- The new `ImageSearchTool.kt` compiled with `kotlinc` against temporary interface/JSON stubs; this checks syntax and the Kotlin-level flow, not real Android integration.
- `scripts/kt_lint.py` ran, but its existing heuristic emits unrelated false-positive import reports in older files. It reports no issue in the files changed for this pass.
- Full Gradle tests/build were not run: `./gradlew :app:testDebugUnitTest --no-daemon --stacktrace` failed before Gradle could start because `services.gradle.org` could not be resolved (`UnknownHostException`). This environment also has no configured Android SDK. Therefore this artifact is a source ZIP, not a tested APK.
