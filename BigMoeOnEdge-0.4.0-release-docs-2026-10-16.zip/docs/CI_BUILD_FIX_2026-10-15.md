# GitHub Actions build failure: `gradlew: No such file or directory`

The uploaded Actions log fails before Gradle starts. The `Unzip project` step runs `unzip -q *.zip -d project`; the delivered source archive stores the app under a top-level `workrepo/` directory. Therefore the wrapper is at `project/workrepo/gradlew` (or `project/gradlew` for an archive without that wrapper folder), while the next step runs `chmod +x gradlew` from the GitHub workspace root. This is a working-directory/path bug in the wrapper workflow, not yet a Gradle, Kotlin, Android SDK, or MTP compile error.

Replace the failing Build step with the following. It discovers the wrapper location for either archive layout and runs Gradle from the actual Android project root:

```yaml
      - name: Build
        shell: bash
        run: |
          set -euo pipefail
          WRAPPER_PATH="$(find project -type f -name gradlew -print -quit)"
          if [[ -z "$WRAPPER_PATH" ]]; then
            echo "ERROR: gradlew was not found under ./project after unzip."
            echo "Extracted files (first 100):"
            find project -maxdepth 4 -type f | sort | head -100 || true
            exit 1
          fi
          PROJECT_ROOT="$(dirname "$WRAPPER_PATH")"
          echo "Android project root: $PROJECT_ROOT"
          test -f "$PROJECT_ROOT/settings.gradle.kts" -o -f "$PROJECT_ROOT/settings.gradle"
          chmod +x "$WRAPPER_PATH"
          cd "$PROJECT_ROOT"
          ./gradlew assembleDebug --no-daemon --stacktrace
```

The failed run did not invoke Gradle, so it provides no evidence yet about whether the Android build itself passes. Re-run the workflow after replacing this step and inspect the next error, if any.
