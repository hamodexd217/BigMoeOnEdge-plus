# Why tool use felt slow, and what changed

## Where the time goes (derived from your numbers, not measured on a device by me)
Prefill on your phone: 13, 35 and 77 prompt tokens took 3.7 s, 5.7 s and 7.0 s, i.e. roughly **19 tokens/s** after a fixed ~3 s.
Decoding runs at about 4 tokens/s. Everything a tool round adds to the conversation is read at the prefill rate, and everything the model
writes is generated at the decode rate:

| cost | size | time at those speeds |
|---|---|---|
| tool list in the system prompt (21 tools) | ~1,770 tokens before this change | ~90 s, paid again whenever the conversation is processed from the start (new chat, or every turn on a hybrid model where `kv_reuse=3`) |
| one tool result at the old 6,000-character cap | ~1,800-2,000 tokens | ~95-105 s |
| a web page read at the old default (4,000 characters) | ~1,200 tokens | ~65 s |
| reasoning again after a tool result | a few hundred tokens | ~1-2 minutes at 4 tokens/s |
| three page reads in one round | 3 x network time | sum of the three, run one after another |

## Changes
* **Shorter tool list** (`ToolManager.getToolsDescriptionPrompt` + every built-in tool's description): no type for string parameters, no line for a parameter whose name says it all, tighter wording that keeps the rules (e.g. "copy old_text from read_file"). About 33 % less text by the same estimate (~1,770 -> ~1,190 tokens).
* **Tool result cap 6,000 -> 3,500 characters by default**, as a setting (Settings > Tool access > Longest tool result: 1,500 / 2,500 / 3,500 / 6,000). Cuts happen at a line break, never inside an emoji, and the model is told how much was left (`[truncated: N more characters not shown]`) so it can ask for a line range or a narrower query. `read_webpage` defaults to 2,500 characters (was 4,000), `extract_webpage` to a 700-token budget (was 1,100).
* **No reasoning after tool results by default** (Settings > Tool access > Think after tool results). The first answer still follows your Thinking switch; rounds that only have to use a tool result answer directly.
* **Network tools run side by side.** When every call in one round is `web_search` / `read_webpage` / `extract_webpage` they run concurrently (`Tool.parallelSafe`); anything that writes keeps its order.
* **Real time limits on the web tools.** A blocked socket read cannot be cancelled, so the 20 s tool timeout did not bound them (6 redirect hops x 2 x 10 s, or a server dripping bytes). `WebFetcher` now has a 15 s wall-clock budget across hops and download (keeps what it already has), the keyless search shares a 12 s budget between DuckDuckGo and Wikipedia, response bodies are bounded, and pages are cut at 1 MB (was 2 MB) before text extraction.
* `search_files` / `search_code` stop after 48 MB read or 8 s instead of scanning up to 2,000 x 1 MB files.
* `analyze_code` compiled two regexes per line of the file; they are compiled once.
* DuckDuckGo parsing dropped the **fifth result's snippet** (the scan stopped right after the fifth title); fixed.

## Not changed (and why)
* **Hybrid models re-process the whole conversation every turn** (`kv_reuse = 3`, see `docs/CTX_AND_KV_REUSE.md`). That multiplies every cost above. The real fix is recurrent-state checkpoints at the prompt / generation-prompt boundary (what llama-server's context checkpoints do). It is a native change I cannot test without a device and the model, so I did not make it blind.
* "Web search: every message" stays the default; it adds the search time and ~400 tokens to every message. Switch to "only when the model asks" to avoid that.
* `run_javascript` builds a WebView per call (a few hundred ms); small next to the model time, and a shared WebView needs on-device testing for isolation.

## Checks
`kt_lint.py`: no findings in the changed tool/workspace files. Kotlin not compiled, new tests (`ToolPerformanceTest`) not run. The size numbers above come from a text estimator over the tool sources, not from a model run.
