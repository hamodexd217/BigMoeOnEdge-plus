# Changelog

User-facing release history for BigMoeOnEdge+. Dates below describe source changes; see each release's notes for validation status and known limitations.

## [0.4.0] — 2026-10-16

See the complete [v0.4.0 release notes](docs/RELEASE_NOTES_0.4.0.md).

### Added
- Primary no-copy GGUF picker for models already in internal/shared storage, with manual-path fallback and copy-import fallback.
- Complete split-GGUF copy import with shard-set validation and single-model presentation.
- Optional separate MTP draft GGUF sidecars for `qwen4exp` models; attachment and controls are separate from the target model.
- Optional Wikimedia Commons image search with thumbnail cards, source links, and available creator/licence metadata.
- Featured premium-inspired warm/light/dark palette group; retained legacy palette IDs and custom nine-colour palettes.
- Portrait chat-history drawer, wider assistant response layout, styled Markdown list markers and horizontally scrollable table-cell rendering.
- Default configuration for fresh installs: blank system prompt, optional tools off, thinking/speculation off, and no explicit generated-token cap (context-limited).
- Organized/collapsible performance and engine settings without removing existing controls.
- UI stream publication/auto-scroll coalescing intended to reduce unnecessary rendering work during generation.

### Improved
- Chat and model-management flows, settings organization, model preflight/status information, Markdown/code/artifact rendering and image result presentation.
- The target MoE model's Expert Streaming remains enabled when a separate MTP sidecar is attached; the sidecar itself still uses ordinary mmap.
- Documentation for direct-path permission handling, model loading, MTP, web/image tools, rendering, API server and release validation.

### Preserved
- Saved conversations, chat editing/copying, per-chat drafts, file/code/utility tools, workspace/artifacts, multimodal attachments, local API server, optional Hexagon/NPU path and prior settings.
- Legacy palette definitions and saved theme identifiers.

### Release caveats
- This is a source release description. Do not mark v0.4.0 as device-verified until the Android build, unit/instrumentation tests and device checklist have passed.
- No-copy path access depends on Android's document provider and permissions; `content://`-only providers may require copying.
- MTP sidecar support is limited to `qwen4exp`; sidecar weights are not served by the target's expert-stream source, and speed-up is not guaranteed.
