package com.bigmoe.onedge.core

/**
 * The engine as the app sees it. The production implementation is [NativeEngineBackend]; tests use a fake,
 * so the controller/agent logic runs on the JVM without libonedge-engine.so.
 */
interface EngineBackend {
    /** Blocking. Returns null on success, otherwise the error message. */
    fun load(modelPath: String, config: LoadConfig, csvPath: String?, mmprojPath: String?, draftPath: String? = null): String?

    /** Capabilities verified by the native runtime, not only build flags. */
    fun capabilities(): EngineCaps

    /** Why HTP prefill is or is not currently available. Fakes remain source-compatible. */
    fun npuPrefillStatus(): String = if (capabilities().npuPrefill) {
        "Available: native HTP session probe succeeded. Actual prompt execution must be confirmed after a run."
    } else {
        "Unavailable: this engine backend does not report a usable Hexagon HTP runtime."
    }

    /** Parsed "key=value" lines from the loaded model (arch, n_ctx, ...). */
    fun modelInfo(): Map<String, String>

    /** Blocking; see [NativeGenerationCallback]. */
    fun generate(
        system: String,
        historyFlat: List<ChatTurn>,
        prompt: String,
        maxTokens: Int,
        clearKv: Boolean,
        think: Boolean,
        images: List<ImageData>,
        callback: NativeGenerationCallback
    )

    /**
     * Blocking, stateless chat generation for the local API server; see [NativeChatCallback]. The default reports
     * "unsupported" so existing backends (and test fakes) need no change.
     */
    fun generateChat(request: ChatGenRequest, callback: NativeChatCallback) {
        callback.onFinished(
            ok = false, cancelled = false, error = encodeUtf8("This backend has no chat API support."),
            answer = ByteArray(0), reasoning = ByteArray(0), toolCalls = emptyArray(), stopReason = ByteArray(0),
            stopSequence = ByteArray(0), nGenerated = 0, nPromptTotal = 0, nReused = 0, nPast = 0,
            tokensPerSecond = 0.0, prefillSeconds = 0.0, cacheHitPct = -1.0
        )
    }

    /**
     * Generation with optional per-request sampler. Existing fake/legacy backends remain compatible;
     * the native backend overrides this and applies sampling without reopening the model.
     */
    fun generateWithSampling(
        system: String,
        historyFlat: List<ChatTurn>,
        prompt: String,
        maxTokens: Int,
        clearKv: Boolean,
        think: Boolean,
        images: List<ImageData>,
        sampling: SamplingOverride?,
        callback: NativeGenerationCallback
    ) = generate(system, historyFlat, prompt, maxTokens, clearKv, think, images, callback)

    /** Thread-safe; makes a running generate() return promptly. */
    /** Blocking multiple-choice decision; returns a probability distribution over [choices]. */
    fun decide(request: DecisionRequest): DecisionResult

    /** Empty means unavailable (including older prebuilt native libraries). */
    fun telemetry(): LongArray = longArrayOf()

    fun stop()

    /** Cancels, waits, releases. */
    fun free()
}

class NativeEngineBackend(private val bridge: EngineNativeBridge) : EngineBackend {

    override fun capabilities(): EngineCaps = EngineCaps.fromBits(bridge.nativeCapabilities())

    override fun npuPrefillStatus(): String = decodeUtf8(bridge.nativeNpuStatus())

    override fun load(modelPath: String, config: LoadConfig, csvPath: String?, mmprojPath: String?, draftPath: String?): String? {
        val err = bridge.nativeLoadModel(
            modelPath = encodeUtf8(modelPath),
            ints = config.toIntArray(),
            floats = config.toFloatArray(),
            csvPath = encodeUtf8(csvPath.orEmpty()),
            mmprojPath = encodeUtf8(mmprojPath.orEmpty()),
            draftPath = encodeUtf8(draftPath.orEmpty())
        )
        return if (err.isEmpty()) null else decodeUtf8(err)
    }

    override fun modelInfo(): Map<String, String> =
        decodeUtf8(bridge.nativeModelInfo()).lineSequence()
            .mapNotNull { line ->
                val i = line.indexOf('=')
                if (i <= 0) null else line.substring(0, i) to line.substring(i + 1)
            }.toMap()

    override fun generate(
        system: String,
        historyFlat: List<ChatTurn>,
        prompt: String,
        maxTokens: Int,
        clearKv: Boolean,
        think: Boolean,
        images: List<ImageData>,
        callback: NativeGenerationCallback
    ) {
        val flat = ArrayList<ByteArray>(historyFlat.size * 2)
        for (t in historyFlat) {
            flat.add(encodeUtf8(t.role))
            flat.add(encodeUtf8(t.content))
        }
        bridge.nativeGenerate(
            system = encodeUtf8(system),
            historyFlat = flat.toTypedArray(),
            prompt = encodeUtf8(prompt),
            maxTokens = maxTokens,
            clearKv = clearKv,
            think = think,
            imageDims = IntArray(images.size * 2) { i -> if (i % 2 == 0) images[i / 2].width else images[i / 2].height },
            imageData = Array(images.size) { images[it].rgb },
            overrideSampling = false,
            temperature = 0f,
            topP = 1f,
            topK = 0,
            seed = -1,
            minP = 0f, repeatPenalty = 1f, repeatLastN = 0, frequencyPenalty = 0f, presencePenalty = 0f,
            callback = callback
        )
    }

    override fun generateWithSampling(
        system: String,
        historyFlat: List<ChatTurn>,
        prompt: String,
        maxTokens: Int,
        clearKv: Boolean,
        think: Boolean,
        images: List<ImageData>,
        sampling: SamplingOverride?,
        callback: NativeGenerationCallback
    ) {
        val flat = ArrayList<ByteArray>(historyFlat.size * 2)
        for (t in historyFlat) { flat.add(encodeUtf8(t.role)); flat.add(encodeUtf8(t.content)) }
        val s = sampling
        bridge.nativeGenerate(
            system = encodeUtf8(system), historyFlat = flat.toTypedArray(), prompt = encodeUtf8(prompt),
            maxTokens = maxTokens, clearKv = clearKv, think = think,
            imageDims = IntArray(images.size * 2) { i -> if (i % 2 == 0) images[i / 2].width else images[i / 2].height },
            imageData = Array(images.size) { images[it].rgb.map { b -> b.toInt() }.let { vals -> ByteArray(vals.size) { idx -> vals[idx].toByte() } } },
            overrideSampling = s != null,
            temperature = s?.temperature ?: 0f, topP = s?.topP ?: 1f, topK = s?.topK ?: 0, seed = s?.seed ?: -1,
            minP = s?.minP ?: 0f, repeatPenalty = s?.repeatPenalty ?: 1f, repeatLastN = s?.repeatLastN ?: 0,
            frequencyPenalty = s?.frequencyPenalty ?: 0f, presencePenalty = s?.presencePenalty ?: 0f,
            callback = callback
        )
    }

    override fun generateChat(request: ChatGenRequest, callback: NativeChatCallback) {
        val s = request.sampling
        bridge.nativeGenerateChat(
            messagesJson = encodeUtf8(request.messagesJson),
            toolsJson = encodeUtf8(request.toolsJson),
            toolChoice = encodeUtf8(request.toolChoice),
            jsonSchema = encodeUtf8(request.jsonSchema),
            stop = Array(request.stop.size) { encodeUtf8(request.stop[it]) },
            maxTokens = request.maxTokens,
            think = request.think,
            overrideSampling = s != null,
            temperature = s?.temperature ?: 0f,
            topP = s?.topP ?: 1f,
            topK = s?.topK ?: 0,
            seed = s?.seed ?: -1,
            minP = s?.minP ?: 0f,
            repeatPenalty = s?.repeatPenalty ?: 1f,
            repeatLastN = s?.repeatLastN ?: 0,
            frequencyPenalty = s?.frequencyPenalty ?: 0f,
            presencePenalty = s?.presencePenalty ?: 0f,
            callback = callback
        )
    }

    override fun decide(request: DecisionRequest): DecisionResult {
        if (request.choices.size < 2) return DecisionResult(ok = false, error = "Give at least two options.")
        val json = decodeUtf8(
            bridge.nativeDecide(
                encodeUtf8(request.prefix),
                encodeUtf8(request.suffix),
                request.choices.map(::encodeUtf8).toTypedArray(),
                request.reusePrefix
            )
        )
        return parseDecision(json, request.choices)
    }

    override fun telemetry(): LongArray = try {
        bridge.nativeTelemetry()
    } catch (_: UnsatisfiedLinkError) {
        // Existing prebuilt libraries remain usable; unavailable must not mean zero performance.
        longArrayOf()
    }

    override fun stop() = bridge.nativeStopGeneration()


    override fun free() = bridge.nativeFreeModel()
}


private fun parseDecision(json: String, choices: List<String>): DecisionResult {
    return runCatching {
        val o = org.json.JSONObject(json)
        val ok = o.optBoolean("ok")
        val error = o.optString("error")
        val cancelled = o.optBoolean("cancelled")
        val logs = o.optJSONArray("choice_logp")
        val scores = choices.indices.map { i ->
            val lp = logs?.optDouble(i, Double.NEGATIVE_INFINITY) ?: Double.NEGATIVE_INFINITY
            val p = if (lp.isFinite()) kotlin.math.exp(lp) else 0.0
            ChoiceScore(
                label = ('A'.code + i).toChar().toString(),
                text = choices[i],
                probability = p
            )
        }
        val metrics = buildString {
            append(String.format(java.util.Locale.US, "prefill %.1fs", o.optDouble("prefill_s", 0.0)))
            append(" (${o.optInt("n_prefilled", 0)} tok")
            val reused = o.optInt("n_reused", 0)
            if (reused > 0) append(", $reused reused")
            append(")")
            val mib = o.optDouble("prefix_state_mib", 0.0)
            if (mib > 0) append(String.format(java.util.Locale.US, " · context kept %.0f MiB", mib))
        }
        DecisionResult(ok = ok, error = error, cancelled = cancelled, scores = scores, best = o.optInt("best", -1), metrics = metrics)
    }.getOrElse { DecisionResult(ok = false, error = "Malformed decide response: ${it.message}") }
}
